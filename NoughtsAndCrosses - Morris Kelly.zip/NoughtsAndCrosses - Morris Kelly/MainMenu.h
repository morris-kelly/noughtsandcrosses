﻿#ifndef HOMEVIEW_H
#define HOMEVIEW_H

#include <QWidget>
#include <QPainterPath>
#include <QPainter>
#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QFile>
#include <gameboard.h>
#include <ShowMainMenu.h>

namespace Ui {
class MainMenu;
}
class QLabel;
class QPixmap;
class QFont;
class QPushButton;

class MainMenu : public QWidget
{
    Q_OBJECT
public:
    explicit MainMenu(QWidget *parent = nullptr);
    QLabel *noughts;
    QLabel *andLabel;
    QLabel *crosse;
    QLabel *noughtPicture;
    QLabel *crossPicture;
    QLabel *dividingLine;
    QPushButton *start;
    QMainWindow *game;
    signals:
    public slots:
    void startGame();

};


#endif // HOMEVIEW_H
