//#ifndef STARTGAME_H
//#define STARTGAME_H

//#include <QObject>
//class ShowMainMenu : public QObject
//{
//    Q_OBJECT
//    ShowMainMenu();

//public:
//public slots:

//};



//#endif // STARTGAME_H
