#ifndef GAMEBOARD_H
#define GAMEBOARD_H

#include <QWidget>
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <stdio.h>
#include <ShowMainMenu.h>
#include <QWindow>
#include <QLayout>
//#include <MainMenu.h>

class QLabel;
class QPixmap;
class QFont;
class QPushButton;

class GameBoard : public QWidget
{
    Q_OBJECT

public:
    explicit GameBoard(QWidget *parent = nullptr);
    int iNoughtScore;
    int iCrossScore;
    QString *noughtScoreText;
    QLabel *GameBoardRectangle;
    QLabel *GameBoardTopLine;
    QLabel *noughtPicture;
    QLabel *noughtScore;
    QLabel *crossPicture;
    QLabel *crossScore;
    QFont *topLabelFont;
    QFont *centralLabelFont;
    QLabel *centralLabel;
    QPushButton *square00;
    QPushButton *square01;
    QPushButton *square02;
    QPushButton *square10;
    QPushButton *square11;
    QPushButton *square12;
    QPushButton *square20;
    QPushButton *square21;
    QPushButton *square22;
    QLabel *line1;
    QLabel *line2;
    QLabel *line3;
    QLabel *line4;

    QPushButton *backButton;
    QPushButton *newGameButton;
    //QWidget *MenuPointer;

    //QPixmap pixMap;
    QString sTurnString;

signals:

public slots:
    void ShowMainMenu();
    void PlayTurn(int, QPushButton * , QPixmap);
};

#endif // GAMEBOARD_H
