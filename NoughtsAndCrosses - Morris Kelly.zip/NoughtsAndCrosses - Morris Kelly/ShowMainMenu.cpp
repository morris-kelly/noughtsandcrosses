//#include "ShowMainMenu.h"
//#include "gameboard.h"
//#include <MainMenu.h>
//#include <QMainWindow>

//ShowMainMenu::ShowMainMenu()
//{

//    //hide();
//    MainMenu newMenu;// = &Menu;
//    newMenu.show();

//    //QMainWindow *mainm = new QMainWindow();

//    //QLayout *menuLayout = new QLayout();

//    //Menu->show();
//    //mainm->setCentralWidget(&newMenu);
//    //mainm->update();
//    //mainm->show();

//    //this->close();
//}

