#include "globals.h"

int iNoughtScore = 0;
int iCrossScore = 0 ;
int iTurn = -1;
int Game[3][3] = {{0}};

