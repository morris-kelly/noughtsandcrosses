#include "gameboard.h"
#include <globals.h>
#include <MainMenu.h>




GameBoard::GameBoard(QWidget *parent) : QWidget(parent)
{
    // set the background colour of the window
    setStyleSheet("background-color: #313131");


    // create the font for the 2 top labels
    QFont topLabelFont("Roboto",QFont::Bold);
    topLabelFont.setPixelSize(21);

    // create the font for the central game label
    QFont centralLabelFont("Roboto Condensed");
    centralLabelFont.setPixelSize(31);

    // create the font for the 2 bottom buttons
    QFont buttonFont("Roboto",QFont::Bold);
    buttonFont.setPixelSize(18);

    // load the nought pixmap from resources
    QPixmap noughtPix;
    noughtPix.load("://nought-01.png");

    // load the cross pixmap from resources
    QPixmap crossPix;
    crossPix.load("://cross-01.png");



    // start by drawing the main rectangle for the gameboard
    GameBoardRectangle = new QLabel(this);
    GameBoardRectangle->setStyleSheet("background-color: #313131");
    QPixmap MainBackgroundPix(490,660);
    MainBackgroundPix.fill("#313131");
    QPainter *startButtonPaint = new QPainter(&MainBackgroundPix);
    startButtonPaint->setPen(QPen(Qt::white,2));
    startButtonPaint->setRenderHint(QPainter::Antialiasing);
    startButtonPaint->drawRoundedRect(QRectF(0,0,490,660),15,15);
    GameBoardRectangle->setPixmap(MainBackgroundPix);
    GameBoardRectangle->adjustSize();
    GameBoardRectangle->move(10,20);

    // draw the top dividing line
    GameBoardTopLine = new QLabel(this);
    QPixmap GameBoardTopLinePix(490,2);
    GameBoardTopLinePix.fill(Qt::white);
    GameBoardTopLine->setPixmap(GameBoardTopLinePix);
    GameBoardTopLine->adjustSize();
    GameBoardTopLine->move(10,87);


    // add the nought pix to a label and display
    noughtPicture = new QLabel(this);
    noughtPicture->setPixmap(noughtPix.scaled(23,23,Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
    noughtPicture->adjustSize();
    noughtPicture->move(30,40);

    // create a string for the noughts score using the global value
    // currently bugged, shows a non-zero value despite the value being set to 0 for startup.
    QString sNoughtScore = "Noughts score: " + QString::number(iNoughtScore);

    // display the initial score of zero
    noughtScore = new QLabel(this);
    noughtScore->setText(sNoughtScore);
    noughtScore->setFont(topLabelFont);
    noughtScore->setStyleSheet("color: white");
    noughtScore->adjustSize();
    // move relative to the nought image
    noughtScore->move(noughtPicture->x()+noughtPicture->width()+10, noughtPicture->y()-1);

    // Load in the cross image from the pixmap
    crossPicture = new QLabel(this);
    crossPicture->setPixmap(crossPix.scaled(23,23,Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
    crossPicture->adjustSize();

    // display the initial score of zero for crosses using the global value
    QString sCrossScore = "Crosses score: " + QString::number(iCrossScore);
    crossScore = new QLabel(this);
    crossScore->setText(sCrossScore);
    crossScore->setFont(topLabelFont);
    crossScore->setStyleSheet("color: white");
    crossScore->adjustSize();
    // move relative to the right side of the screen
    crossScore->move(500-20-crossScore->width(), noughtPicture->y()-2);

    // move the crosses picture relative to the crosses score (needs to be done after it exists)
    crossPicture->move(crossScore->x()-crossPicture->width()-10,40);


    // Add in the central label with text, changing based on the turn ID"
    if (iTurn == -1)
    {
        sTurnString = "crosses turn!";
    }
    if (iTurn == 1)
    {
        sTurnString = "noughts turn!";
    }

    centralLabel = new QLabel(this);
    centralLabel->setText(sTurnString);
    centralLabel->setFont(centralLabelFont);
    centralLabel->setStyleSheet("color: white");
    centralLabel->adjustSize();
    // position centrally based on fixed width window
    centralLabel->move(255-centralLabel->width()/2,120);

    // define the size of each of the buttons and create them in turn.
    // named to match the array that will hold the game data (indices of items)
    int iSquareSize = 120;
    square00 = new QPushButton(this);
    square00->setFixedSize(iSquareSize,iSquareSize);
    square00->setFlat(true);
    square00->move(75,185);

    square01 = new QPushButton(this);
    square01->setFixedSize(iSquareSize,iSquareSize);
    square01->setFlat(true);
    square01->move(square00->x()+iSquareSize+2,185);

    square02 = new QPushButton(this);
    square02->setFixedSize(iSquareSize,iSquareSize);
    square02->setFlat(true);
    square02->move(square01->x()+iSquareSize+2,185);

    square10= new QPushButton(this);
    square10->setFixedSize(iSquareSize,iSquareSize);
    square10->setFlat(true);
    square10->move(75,185+122);

    square11 = new QPushButton(this);
    square11->setFixedSize(iSquareSize,iSquareSize);
    square11->setFlat(true);
    square11->move(square10->x()+iSquareSize+2,185+122);

    square12 = new QPushButton(this);
    square12->setFixedSize(iSquareSize,iSquareSize);
    square12->setFlat(true);
    square12->move(square11->x()+iSquareSize+2,185+122);

    square20= new QPushButton(this);
    square20->setFixedSize(iSquareSize,iSquareSize);
    square20->setFlat(true);
    square20->move(75,185+122+122);

    square21 = new QPushButton(this);
    square21->setFixedSize(iSquareSize,iSquareSize);
    square21->setFlat(true);
    square21->move(square20->x()+iSquareSize+2,185+122+122);

    square22 = new QPushButton(this);
    square22->setFixedSize(iSquareSize,iSquareSize);
    square22->setFlat(true);
    square22->move(square21->x()+iSquareSize+2,185+122+122);


    // create and set a pixmap based on the turn number
    QPixmap pixMap;
    if (iTurn  == -1){
        pixMap = crossPix;
    }
    else if (iTurn == 1) {
        pixMap = noughtPix;
    }

    // connect all the buttons to update the icon when clicked. call the "play turn" function with the square ID and a pixmap.
    QObject::connect(square00,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square00,pixMap);});
    QObject::connect(square01,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square01,pixMap);});
    QObject::connect(square02,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square02,pixMap);});
    QObject::connect(square10,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square10,pixMap);});
    QObject::connect(square11,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square11,pixMap);});
    QObject::connect(square12,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square12,pixMap);});
    QObject::connect(square20,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square20,pixMap);});
    QObject::connect(square21,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square21,pixMap);});
    QObject::connect(square22,&QPushButton::clicked,    [=](){PlayTurn(iTurn,square22,pixMap);});

    // define pixmaps for the dividing game board lines
    QPixmap vertLinePix(2,364);
    vertLinePix.fill(Qt::white);

    QPixmap horizLinePix(364,2);
    horizLinePix.fill(Qt::white);

    //add these to the board based on the positions of the buttons/squares
    line1 = new QLabel(this);
    line1->setPixmap(vertLinePix);
    line1->move(square00->x()+120,square00->y());

    line2 = new QLabel(this);
    line2->setPixmap(vertLinePix);
    line2->move(square01->x()+120,square00->y());


    line3 = new QLabel(this);
    line3->setPixmap(horizLinePix);
    line3->move(square00->x(),square00->y()+iSquareSize);

    line4 = new QLabel(this);
    line4->setPixmap(horizLinePix);
    line4->move(square00->x(),square10->y()+iSquareSize);

    // Add the start button (rounded rectangle with text, filled)
    backButton = new QPushButton(this);
    backButton->setText("Back");
    backButton->setFixedSize(235,62);
    backButton->setFont(buttonFont);
    backButton->setFlat(true);
    backButton->setStyleSheet("border-style: solid;"
                              "border-color: white;"
                              "border-width: 2px;"
                              "border-radius: 31px;"
                              "color: white;");
    //"background-color: #ffffff");
    backButton->move(10,713);

    // Add the start button (rounded rectangle with text, no fill)
    newGameButton = new QPushButton(this);
    newGameButton->setText("New game");
    newGameButton->setFixedSize(235,62);
    newGameButton->setFont(buttonFont);
    newGameButton->setFlat(true);
    newGameButton->setStyleSheet("border-style: solid;"
                                 "border-color: white;"
                                 "border-width: 1px;"
                                 "border-radius: 31px;"
                                 "color: black;"
                                 "background-color: #ffffff");
    newGameButton->move(backButton->x()+backButton->width()+20,713);

// connect up both of these buttons, using new syntax for the back button to call a function. was used for debugging and moving the function
    QObject::connect(newGameButton,SIGNAL(pressed()), this,SLOT(show()));
    QObject::connect(backButton,&QPushButton::clicked,    [=](){ShowMainMenu();});

    // set the size of the window
    setFixedSize(510,853);
}

// slot for the back button to call
void GameBoard::ShowMainMenu()
{
// hide the gameboard
    hide();
    // reset the scores to 0
    iNoughtScore = 0;
    iCrossScore = 0;
    // show the main menu
    MainMenu newMenu;// = &Menu;
    newMenu.show();


    // below relates to emailed questions, I think I have a misunderstanding of the parent/child system

    //QMainWindow *mainm = new QMainWindow();

    //QLayout *menuLayout = new QLayout();

    //Menu->show();
    //mainm->setCentralWidget(&newMenu);
    //mainm->update();
    //mainm->show();

    //this->close();
}

// slot for the play buttons to call
void GameBoard::PlayTurn(int iTurns, QPushButton * button, QPixmap pix)
{
    // assign the icon based on the pixmap fed into the function
    QIcon ButtonIcon(pix);
        button->setIcon(ButtonIcon);
        button->setIconSize(QSize(64,64));
        // write to the game array with the turn ID. based on button naming
        if (button->objectName() == "square00")
        {
            Game[0][0] = iTurns;
        }
        else if (button->objectName() == "square01") {
            Game[0][1] = iTurns;
        }
        else if (button->objectName() == "square02") {
            Game[0][2] = iTurns;
        }
        else if (button->objectName() == "square10") {
            Game[1][0] = iTurns;
        }
        else if (button->objectName() == "square11") {
            Game[1][1] = iTurns;
        }
        else if (button->objectName() == "square12") {
            Game[1][2] = iTurns;
        }
        else if (button->objectName() == "square20") {
            Game[2][0] = iTurns;
        }
        else if (button->objectName() == "square21") {
            Game[2][1] = iTurns;
        }
        else if (button->objectName() == "square22") {
            Game[2][2] = iTurns;
        }

//        // the big if-else statement should really be a switch case with the enum, ran out of time.
//        e.g.:
//        typedef enum  button_Number{
//            square00,
//            square01,
//            square02,
//            square10,
//            square11,
//            square12,
//            square20,
//            square21,
//            square22

//        } ;
//        switch (button_Number) {

//        }



        // check for the board being full first, for the case of a draw.
        // if all items in the array are not equal to zero

        bool fullBoard = std::find(Game[0], Game[3-1]+3, 0);

        // set the label = 'its a draw'
        // don't add to the scores

        // add up all the possible lines in the arry for a winning score.
        int SumLine1 = Game[0][0] + Game[0][1] + Game[0][2];
        int SumLine2 = Game[1][0] + Game[1][1] + Game[1][2];
        int SumLine3 = Game[2][0] + Game[2][1] + Game[2][2];
        int SumLine4 = Game[0][0] + Game[1][0] + Game[2][0];
        int SumLine5 = Game[0][1] + Game[1][1] + Game[2][1];
        int SumLine6 = Game[0][1] + Game[1][1] + Game[2][1];
        int SumDiag1 = Game[0][0] + Game[1][1] + Game[2][2];
        int SumDiag2 = Game[0][2] + Game[1][1] + Game[2][0];

        // put these sums into an array
        int Sums[8] = {SumLine1,SumLine2,SumLine3,SumLine4,SumLine5,SumLine6,SumDiag1,SumDiag2};

        size_t ArraySize = sizeof(Sums) / sizeof(int);

        int *end = Sums + ArraySize;
        // look for a nought win
        int *WinningScoreNought = std::find(Sums, end, 3);
        // if this is true then deal with the victory
        if (WinningScoreNought != end)
        {
            // noughts win
            // write text to label, increase the score
            iNoughtScore++;
        }

        // search for a cross win and deal with this also. increase score, update label
        int *WinningScoreCross = std::find(Sums, end, -3);

        if (WinningScoreCross != end)
        {
            // crosses win
            // write text to label with this
            iCrossScore++;
        }


// after the turn is complete, flip the turn ID to show noughts/crosses as required
        iTurn = -1*iTurn;
}


