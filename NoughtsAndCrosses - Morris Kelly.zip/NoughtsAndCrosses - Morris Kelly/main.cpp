#include "MainMenu.h"
#include <QApplication>
#include <QApplication>
#include <QMainWindow>
#include <QVBoxLayout>
#include <QPushButton>
#include <QtCore/QFile>
#include <QLayout>
#include <QLabel>
#include <qfont.h>
#include <QPixmap>
#include <QColor>
#include <gameboard.h>
using namespace std;

// Morris Kelly 29/3/19

// game is not in a complete state
// overall thought was to use an array for the game, and global variables.
// the turn ID represents the piece who's turn it is to play
// -1 is a cross, 1 is a nought
// these values then written to an array will give the outcome of a draw, victory or loss based on searching the array.
// some small bugs to iron out, primarily switching piece turns and re-drawing the game board labels
// also need to correctly deal with the signals and switches on the buttons that will open new windows.

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    // main menu currently does not launch new game correctly, couldn't work out
    // order of operations and parent/children/widget/layout relationship.

    // if uncommented however, does match spec.
    //MainMenu w;
    //w.show();


    // show the game board
    GameBoard x;
    x.show();

    return a.exec();
}


