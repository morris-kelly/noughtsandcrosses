#include "MainMenu.h"
#include "gameboard.h"
#include <QLabel>
#include <QPushButton>

MainMenu::MainMenu (QWidget *parent) : QWidget(parent)
{
    // set the background colour
    setStyleSheet("background-color: #313131");

    // create the font for the label
    QFont labelFont("Roboto Condensed Regular");
    labelFont.setPixelSize(58);

    // add noughts label with formatting and location
    noughts = new QLabel(this);
    noughts->setText("noughts");
    noughts->setFont(labelFont);
    noughts->setStyleSheet("color: rgb(240,129,19)");
    noughts->adjustSize();
    noughts->move(5,270);

    // add the plus text and colour white
    andLabel = new QLabel(this);
    andLabel ->setText("+");
    andLabel ->setFont(labelFont);
    andLabel ->setStyleSheet("color: rgb(255,255,255)");
    andLabel ->adjustSize();
    andLabel ->move(noughts->x() + noughts->width()+10,270);

    QLabel* crosses = new QLabel(this);
    crosses->setText("crosses");
    crosses->setFont(labelFont);
    crosses->setStyleSheet("color: rgb(184,57,142)");
    crosses->adjustSize();
    crosses->move(andLabel->x() +  andLabel->width() + 10,270);

    //with the labels added, set the width of the app to a minimum to allow the text to fit in with padding
    int iPadding = 10;
    int iWidth = iPadding+noughts->width()+iPadding+andLabel->width()
            +crosses->width()+iPadding;
    setFixedSize(iWidth,850);


    // Load in the nought picture
    noughtPicture = new QLabel(this);
    QPixmap noughtPix;
    noughtPix.load("://nought-01.png");
    noughtPicture->setPixmap(noughtPix.scaled(46,46));
    noughtPicture->adjustSize();
    noughtPicture->move(andLabel->x() + (andLabel->width()/2)-66,430);

    // Load in the cross image
    crossPicture     = new QLabel(this);
    QPixmap crossPix;
    crossPix.load("://cross-01.png");
    crossPicture->setPixmap(crossPix.scaled(46,46));
    crossPicture->adjustSize();
    crossPicture->move(andLabel->x() + (andLabel->width()/2)+20,430);

    // add the central line
    dividingLine = new QLabel(this);
    QPixmap dividingLinePix(2,80);
    dividingLinePix.fill(Qt::white);
    dividingLine->setPixmap(dividingLinePix);
    dividingLine->adjustSize();
    dividingLine->move(andLabel->x() + (andLabel->width()/2),413);

    // Add the start button (rounded rectangle with text)
    start = new QPushButton(this);
    QFont startButtonFont("Roboto",QFont::Bold);
    startButtonFont.setPixelSize(18);
    start->setText("Start Game");
    start->setFixedSize(iWidth/3,62);
    start->setFont(startButtonFont);
    start->setFlat(true);
    start->setStyleSheet("border-style: solid;"
                         "border-color: white;"
                         "border-width: 5px;"
                         "border-radius: 31px;"
                         "background-color: #ffffff");
    start->move(iWidth/3,850-140);

    connect(start,SIGNAL(clicked()),this,SLOT(startGame()));
}
void MainMenu::startGame()
{
    game = new QMainWindow();

    GameBoard Game;
    game->setCentralWidget(&Game);
    game->show();

}





