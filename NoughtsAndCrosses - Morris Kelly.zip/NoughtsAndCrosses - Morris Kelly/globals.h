#ifndef GLOBALS_H
#define GLOBALS_H


extern int iNoughtScore;
extern int iCrossScore;
extern int iTurn;
extern int Game[3][3];
#endif // GLOBALS_H
